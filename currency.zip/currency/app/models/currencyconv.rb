class Currencyconv < ApplicationRecord
    validates :currency_type1, :currency_type2, :curr, presence: true
end

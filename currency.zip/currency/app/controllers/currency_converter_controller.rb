class CurrencyConverterController < ApplicationController
 def new
    @currency = Currencyconv.new
 end

 def create
    @currency = Currencyconv.new(currency_converter_params)
    if @currency.save
      redirect_to root_path, notice: 'currency converted'
    else
      render :new
    end
  end

  private

  def currency_converter_params
    params.require(:currency).permit(:currency_type1, :currency_type2, :curr)
  end
end

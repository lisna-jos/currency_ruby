class CreateCurrencyconvs < ActiveRecord::Migration[7.0]
  def change
    create_table :currencyconvs do |t|
      t.string :currency_type1
      t.string :currency_type2
      t.float :curr

      t.timestamps
    end
  end
end

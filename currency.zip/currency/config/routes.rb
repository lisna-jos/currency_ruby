Rails.application.routes.draw do
 
  resources :currency_converter, only: [:new, :create]
  root 'home#index'
  
end 